import pygame
import socket
import pickle
import threading
import sys
import time
import os

# --- Network Configuration ---
# IMPORTANT: Change this to the local IP address of the computer running the server.
SERVER_HOST = '127.0.0.1' 
SERVER_PORT = 65432
HEADER_LENGTH = 10  # Must match server

# --- Pygame Initialization ---
pygame.init()

# --- Screen Dimensions ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("RPS Game Client")
fullscreen = False

# --- Colors ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (100, 100, 100)
BLUE = (100, 100, 255)
RED = (255, 100, 100)
GREEN = (100, 255, 100)
YELLOW = (255, 255, 150)
HP_RED = (200, 0, 0)
HP_GREEN = (0, 200, 0)
HOVER_COLOR = (255, 200, 0, 100)
SHADOW_COLOR = (50, 50, 50)
# New color for "GAME OVER!" text
GAME_OVER_RED = (249, 4, 4)

# --- Fonts ---
try:
    font_name = 'BADABB__.TTF'
    font_large = pygame.font.Font(font_name, 74)
    font_medium = pygame.font.Font(font_name, 50)
    font_small = pygame.font.Font(font_name, 36)
    font_hp = pygame.font.Font(font_name, 28)
    font_card_name = pygame.font.Font(font_name, 28) 
    font_card_effect = pygame.font.Font(font_name, 22)
    font_round_result = pygame.font.Font(font_name, 48)
    font_section_title = pygame.font.Font(font_name, 40)
    font_end_screen = pygame.font.Font(font_name, 150)
except FileNotFoundError:
    print("Warning: Font 'BADABB__.TTF' not found. Falling back to default font.")
    font_name = None
    font_large = pygame.font.Font(font_name, 74)
    font_medium = pygame.font.Font(font_name, 50)
    font_small = pygame.font.Font(font_name, 36)
    font_hp = pygame.font.Font(font_name, 28)
    font_card_name = pygame.font.Font(font_name, 28)
    font_card_effect = pygame.font.Font(font_name, 22)
    font_round_result = pygame.font.Font(font_name, 48)
    font_section_title = pygame.font.Font(font_name, 40)
    font_end_screen = pygame.font.Font(font_name, 150)


# --- Game State Variables (Client-side) ---
player_id = None
game_message = "Connecting to server..."
player_hps = {0: 100, 1: 100}
round_status = "connecting"
player_choice = None
game_over = False
local_player_won = False
player_hand = []
revealed_player_card_data = None
revealed_opponent_card_data = None

# --- Animation State ---
end_screen_text_scale = 0.0
end_screen_animation_active = False
end_screen_text_velocity = 0.0
spring = 0.04
damping = 0.75


# --- UI and Game Constants ---
INITIAL_HP = 100
CHOICES_MAP = {0: "Rock", 1: "Paper", 2: "Scissors"}
CARD_EFFECTS_DISPLAY = {
    "none": "No Effect",
    "power_attack": "Power Attack (20 Dmg)",
    "counter_damage_5": "Counter (5 Dmg if Lose)"
}
NORMAL_SCALE, HOVER_SCALE, SCALE_SPEED = 1.0, 1.1, 0.08
TILT_ANGLE = 10 
TILT_SPEED = 0.1 

# --- Asset Loading ---
ASSETS_DIR = os.path.join(os.path.dirname(__file__), 'assets')
MAX_CARD_IMAGE_HEIGHT = 100
card_images = {
    0: {0: None, 1: None, 2: None}, 1: {0: None, 1: None, 2: None}, 'default': {0: None, 1: None, 2: None}
}
player_0_background, player_1_background = None, None
win_screen_img, lose_screen_img = None, None

def load_and_scale_image(file_name, max_height):
    path = os.path.join(ASSETS_DIR, file_name)
    try:
        image = pygame.image.load(path).convert_alpha()
        if max_height > 0:
            w, h = image.get_size()
            scale = max_height / h
            return pygame.transform.smoothscale(image, (int(w * scale), max_height))
        return image
    except (pygame.error, FileNotFoundError) as e:
        print(f"Warning: Could not load {file_name}. {e}")
        return None

# --- Load all assets ---
player_0_background = load_and_scale_image('player2screen_bg.png', 0)
player_1_background = load_and_scale_image('player1screen_bg.png', 0)
win_screen_img = load_and_scale_image('win_screen.png', 0)
lose_screen_img = load_and_scale_image('lose_screen.png', 0)


for p_id in [0, 1, 'default']:
    for rps_val in [0, 1, 2]:
        suffix = str(p_id) if p_id != 'default' else ''
        filename = f"{CHOICES_MAP[rps_val].lower()}{suffix}.png"
        card_images[p_id][rps_val] = load_and_scale_image(filename, MAX_CARD_IMAGE_HEIGHT)

# --- Network Socket ---
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connected_to_server = False

# --- Drawing Functions ---

def draw_text_with_shadow(text, font, color, x, y, center=True, stroke=True):
    text_surface = font.render(text, True, color)
    shadow_surface = font.render(text, True, SHADOW_COLOR)

    shadow_rect = shadow_surface.get_rect(center=(x + 3, y + 3) if center else (x + 3, y + 3))
    screen.blit(shadow_surface, shadow_rect)

    if stroke:
        stroke_surface = font.render(text, True, BLACK)
        stroke_offsets = [(-1, -1), (1, -1), (-1, 1), (1, 1), (-1, 0), (1, 0), (0, -1), (0, 1)]
        for dx, dy in stroke_offsets:
            stroke_rect = stroke_surface.get_rect(center=(x + dx, y + dy) if center else (x + dx, y + dy))
            screen.blit(stroke_surface, stroke_rect)
    
    text_rect = text_surface.get_rect(center=(x, y) if center else (x,y))
    screen.blit(text_surface, text_rect)

def draw_wrapped_text_with_shadow(text, font, color, rect):
    def get_lines(txt, f, max_width):
        words = txt.split(' ')
        lines = []
        current_line = ""
        for word in words:
            if f.size(current_line + word)[0] < max_width:
                current_line += word + " "
            else:
                lines.append(current_line)
                current_line = word + " "
        lines.append(current_line)
        return lines

    current_font = font
    lines = get_lines(text, current_font, rect.width)
    total_text_height = len(lines) * current_font.get_linesize()

    if total_text_height > rect.height:
        current_font = font_small
        lines = get_lines(text, current_font, rect.width)
        total_text_height = len(lines) * current_font.get_linesize()

    y_start = rect.centery - (total_text_height / 2)
    for i, line in enumerate(lines):
        draw_text_with_shadow(line.strip(), current_font, color, rect.centerx, y_start + i * current_font.get_linesize() + current_font.get_linesize() / 2)


def draw_hp_bar(current_hp, max_hp, x, y, width, height, player_label):
    if current_hp < 0: current_hp = 0
    hp_ratio = current_hp / max_hp
    pygame.draw.rect(screen, HP_RED, (x, y, width, height), border_radius=5)
    pygame.draw.rect(screen, HP_GREEN, (x, y, width * hp_ratio, height), border_radius=5)
    pygame.draw.rect(screen, BLACK, (x, y, width, height), 2, border_radius=5)
    draw_text_with_shadow(f"{player_label}: {int(current_hp)} HP", font_hp, WHITE, x + width / 2, y + height / 2)

def draw_button(rect, text, font, color, text_color, hover_color=None):
    mouse_pos = pygame.mouse.get_pos()
    is_hovered = rect.collidepoint(mouse_pos)
    current_color = hover_color if is_hovered and hover_color else color
    pygame.draw.rect(screen, current_color, rect, border_radius=10)
    pygame.draw.rect(screen, BLACK, rect, 3, border_radius=10)
    draw_text_with_shadow(text, font, text_color, rect.centerx, rect.centery)
    return is_hovered

def draw_card_as_image_button(x, y, card_data, is_selected, is_clickable=True, extra_scale=1.0):
    rps_value = card_data["rps_value"]
    effect_text = CARD_EFFECTS_DISPLAY.get(card_data["effect"], "Unknown")
    card_name = CHOICES_MAP.get(rps_value, "???")
    
    owner_id = card_data.get("owner", player_id) 
    image_set = card_images.get(owner_id, card_images['default'])
    base_image = image_set.get(rps_value, card_images['default'].get(rps_value))

    current_scale = card_data.get("current_scale", NORMAL_SCALE) * extra_scale
    current_tilt = card_data.get("current_tilt", 0)

    scaled_w = int(base_image.get_width() * current_scale)
    scaled_h = int(base_image.get_height() * current_scale)
    
    scaled_image = pygame.transform.smoothscale(base_image, (scaled_w, scaled_h))
    
    display_image = scaled_image
    border_padding = 10
    
    if is_selected:
        tight_rect = scaled_image.get_bounding_rect()
        bordered_surface_size = (tight_rect.width + border_padding, tight_rect.height + border_padding)
        bordered_surface = pygame.Surface(bordered_surface_size, pygame.SRCALPHA)
        
        pygame.draw.rect(bordered_surface, GREEN, bordered_surface.get_rect(), 4, border_radius=8)
        
        card_pos_in_surface = ((bordered_surface_size[0] - scaled_w) / 2, (bordered_surface_size[1] - scaled_h) / 2)
        bordered_surface.blit(scaled_image, card_pos_in_surface)
        
        display_image = pygame.transform.rotozoom(bordered_surface, current_tilt, 1)

    image_rect = display_image.get_rect(centerx=x, top=y)
    screen.blit(display_image, image_rect)

    text_y_anchor = image_rect.bottom + 10
    name_surface = font_card_name.render(card_name, True, WHITE)
    name_rect = name_surface.get_rect(centerx=x, top=text_y_anchor)
    
    effect_surface = font_card_effect.render(effect_text, True, WHITE)
    effect_rect = effect_surface.get_rect(centerx=x, top=name_rect.bottom)
    
    draw_text_with_shadow(card_name, font_card_name, WHITE, name_rect.centerx, name_rect.centery)
    draw_text_with_shadow(effect_text, font_card_effect, WHITE, effect_rect.centerx, effect_rect.centery)

    interaction_rect = image_rect.unionall([name_rect, effect_rect])
    
    return interaction_rect


def draw_game_screen(sw, sh):
    if game_over:
        end_bg = win_screen_img if local_player_won else lose_screen_img
        end_text_str = "YOU WIN!" if local_player_won else "GAME OVER!"
        end_text_color = WHITE if local_player_won else GAME_OVER_RED

        if end_bg:
            screen.blit(pygame.transform.scale(end_bg, (sw, sh)), (0, 0))
        else:
            screen.fill(DARK_GRAY)

        text_surface = font_end_screen.render(end_text_str, True, end_text_color)
        stroke_surface = font_end_screen.render(end_text_str, True, BLACK)

        scaled_width = int(text_surface.get_width() * end_screen_text_scale)
        scaled_height = int(text_surface.get_height() * end_screen_text_scale)
        
        if scaled_width > 0 and scaled_height > 0:
            scaled_text = pygame.transform.smoothscale(text_surface, (scaled_width, scaled_height))
            scaled_stroke = pygame.transform.smoothscale(stroke_surface, (scaled_width, scaled_height))
            
            text_rect = scaled_text.get_rect(center=(sw / 2, sh / 2))

            stroke_offsets = [(-2, -2), (2, -2), (-2, 2), (2, 2), (-2, 0), (2, 0), (0, -2), (0, 2)]
            for dx, dy in stroke_offsets:
                stroke_rect = scaled_stroke.get_rect(center=(text_rect.centerx + dx, text_rect.centery + dy))
                screen.blit(scaled_stroke, stroke_rect)

            screen.blit(scaled_text, text_rect)
            
        return

    bg = player_1_background if player_id == 1 else player_0_background
    if bg: screen.blit(pygame.transform.scale(bg, (sw, sh)), (0, 0))
    else: screen.fill(DARK_GRAY)

    if player_id is not None:
        insta_win_rect = pygame.Rect(sw - 160, 10, 150, 40)
        draw_button(insta_win_rect, "Insta-Win", font_card_effect, RED, WHITE, hover_color=BLUE)

    draw_text_with_shadow("Rock Paper Scissors", font_large, YELLOW, sw / 2, 50)
    if player_id is not None:
        draw_text_with_shadow(f"You are Player: {player_id}", font_medium, WHITE, sw / 2, 120)
    
    hp_bar_width, hp_bar_height, hp_bar_y = 250, 35, 180
    draw_hp_bar(player_hps.get(0, 0), INITIAL_HP, sw / 2 - hp_bar_width - 20, hp_bar_y, hp_bar_width, hp_bar_height, "Player 0")
    draw_hp_bar(player_hps.get(1, 0), INITIAL_HP, sw / 2 + 20, hp_bar_y, hp_bar_width, hp_bar_height, "Player 1")
    
    if round_status == "round_over":
        summary_rect = pygame.Rect(50, sh * 0.4, sw - 100, sh * 0.2)
        draw_wrapped_text_with_shadow(game_message, font_round_result, YELLOW, summary_rect)
        
        is_large_screen = sw > SCREEN_WIDTH * 1.2 or sh > SCREEN_HEIGHT * 1.2
        card_scale = 1.8 if is_large_screen else 1.0
        revealed_y_pos = summary_rect.bottom + 20
        
        draw_text_with_shadow("Player 0's Card", font_small, WHITE, sw/4, revealed_y_pos)
        draw_text_with_shadow("Player 1's Card", font_small, WHITE, sw * 3/4, revealed_y_pos)
        p0_card = revealed_player_card_data if player_id == 0 else revealed_opponent_card_data
        p1_card = revealed_opponent_card_data if player_id == 0 else revealed_player_card_data
        p0_card["owner"] = 0
        p1_card["owner"] = 1
        draw_card_as_image_button(sw/4, revealed_y_pos + 40, p0_card, False, is_clickable=False, extra_scale=card_scale)
        draw_card_as_image_button(sw * 3/4, revealed_y_pos + 40, p1_card, False, is_clickable=False, extra_scale=card_scale)
    
    elif round_status in ["waiting_for_choices", "choice_made"]:
        draw_text_with_shadow(game_message, font_small, WHITE, sw / 2, 260)
        
        is_large_screen = sw > SCREEN_WIDTH * 1.2 or sh > SCREEN_HEIGHT * 1.2
        if is_large_screen:
            card_base_height = sh * 0.20 # Cards are 20% of screen height
            card_scale = card_base_height / MAX_CARD_IMAGE_HEIGHT
            card_y_pos = sh * 0.55 # Position cards higher up
            card_spacing = sw / 4 
        else:
            card_y_pos = sh - 280
            card_scale = 1.0
            card_spacing = 200

        num_cards = len(player_hand)
        total_hand_width = (num_cards - 1) * card_spacing
        start_x = (sw / 2) - (total_hand_width / 2)
        
        for i, card_data in enumerate(player_hand):
            is_selected = (player_choice == card_data)
            card_x_pos = start_x + i * card_spacing
            card_rect = draw_card_as_image_button(card_x_pos, card_y_pos, card_data, is_selected, is_clickable=True, extra_scale=card_scale)
            card_data["rect"] = card_rect
    else: 
        draw_text_with_shadow(game_message, font_small, WHITE, sw / 2, 260)
        
    if round_status == "waiting_for_players":
        ready_rect = pygame.Rect(sw // 2 - 100, sh - 150, 200, 60)
        draw_button(ready_rect, "Ready", font_medium, GREEN, WHITE, hover_color=BLUE)

# --- Network Communication Thread ---

def send_message(message_type, data):
    global connected_to_server, game_message
    if not connected_to_server: return
    message_object = {"type": message_type, "data": data}
    try:
        pickled_data = pickle.dumps(message_object)
        header = f"{len(pickled_data):<{HEADER_LENGTH}}".encode('utf-8')
        client_socket.sendall(header + pickled_data)
    except socket.error as e:
        print(f"Failed to send message: {e}")
        connected_to_server = False
        game_message = "Connection lost while sending."

def receive_messages():
    global player_id, game_message, player_hps, round_status, game_over, player_hand, connected_to_server
    global revealed_player_card_data, revealed_opponent_card_data, local_player_won, end_screen_text_scale, end_screen_animation_active, end_screen_text_velocity
    
    full_msg = b''
    new_msg = True
    while connected_to_server:
        try:
            chunk = client_socket.recv(4096)
            if not chunk:
                print("Server disconnected.")
                connected_to_server = False; break
            
            full_msg += chunk
            while True:
                if new_msg:
                    if len(full_msg) < HEADER_LENGTH: break
                    msg_len = int(full_msg[:HEADER_LENGTH])
                    new_msg = False
                if len(full_msg) - HEADER_LENGTH < msg_len: break
                
                data_object = pickle.loads(full_msg[HEADER_LENGTH : HEADER_LENGTH + msg_len])
                msg_type, msg_data = data_object.get("type"), data_object.get("data")
                
                if msg_type == "player_id":
                    player_id = msg_data["id"]
                    game_message = f"Welcome, Player {player_id}. Waiting for opponent..."
                elif msg_type == "game_state":
                    game_message, player_hps, round_status = msg_data["message"], msg_data["hps"], msg_data["round_status"]
                    game_over, end_screen_animation_active = msg_data.get("game_over", False), False
                    
                    new_hand = []
                    for card in msg_data.get("player_hand", []):
                        card_with_anim = card.copy()
                        card_with_anim["current_scale"] = NORMAL_SCALE
                        card_with_anim["current_tilt"] = 0
                        new_hand.append(card_with_anim)
                    player_hand = new_hand
                    
                    if round_status in ["waiting_for_choices", "waiting_for_players"]:
                        player_choice, revealed_player_card_data, revealed_opponent_card_data = None, None, None
                elif msg_type == "round_result":
                    player_hps, round_status, game_over = msg_data["hps"], msg_data["round_status"], msg_data.get("game_over", False)
                    game_message = msg_data["message"] 
                    
                    if game_over and not end_screen_animation_active:
                        win_string = f"Player {player_id} wins the game!"
                        local_player_won = win_string in game_message or "draw" not in game_message.lower() and str(1-player_id) not in game_message
                        end_screen_text_scale = 0.0
                        end_screen_text_velocity = 0.0
                        end_screen_animation_active = True

                    revealed_player_card_data = msg_data["player0_choice"] if player_id == 0 else msg_data["player1_choice"]
                    revealed_opponent_card_data = msg_data["player1_choice"] if player_id == 0 else msg_data["player0_choice"]

                full_msg = full_msg[HEADER_LENGTH + msg_len:]
                new_msg = True
                if not full_msg: break

        except (socket.error, pickle.UnpicklingError, EOFError, ValueError, IndexError) as e:
            print(f"Error in receive thread: {e}")
            connected_to_server = False; break

# --- Main Game Loop ---
def game_loop():
    global connected_to_server, player_choice, round_status, game_message, game_over, end_screen_text_scale, end_screen_text_velocity
    global screen, fullscreen

    try:
        client_socket.connect((SERVER_HOST, SERVER_PORT))
        connected_to_server = True
        threading.Thread(target=receive_messages, daemon=True).start()
    except socket.error as e:
        game_message = "Could not connect to server."
        print(f"{game_message} Error: {e}")
        connected_to_server = False

    running, clock = True, pygame.time.Clock()
    while running:
        sw, sh = screen.get_width(), screen.get_height()
        mouse_pos = pygame.mouse.get_pos()
        
        # --- Handle Animations ---
        if game_over and end_screen_animation_active:
            target_scale = 1.0
            force = (target_scale - end_screen_text_scale) * spring
            end_screen_text_velocity += force
            end_screen_text_velocity *= damping
            end_screen_text_scale += end_screen_text_velocity
        
        for card_data in player_hand:
            is_selected = (player_choice == card_data)
            is_hovered = "rect" in card_data and card_data["rect"] and card_data["rect"].collidepoint(mouse_pos)
            
            target_scale = HOVER_SCALE if is_hovered or is_selected else NORMAL_SCALE
            target_tilt = TILT_ANGLE if is_selected else 0

            card_data["current_scale"] += (target_scale - card_data["current_scale"]) * SCALE_SPEED
            card_data["current_tilt"] += (target_tilt - card_data["current_tilt"]) * TILT_SPEED
        
        # --- Event Handling ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False
            if event.type == pygame.VIDEORESIZE:
                if not fullscreen:
                    screen = pygame.display.set_mode(event.size, pygame.RESIZABLE)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                fullscreen = not fullscreen
                mode = pygame.FULLSCREEN if fullscreen else pygame.RESIZABLE
                screen = pygame.display.set_mode((0, 0) if fullscreen else (SCREEN_WIDTH, SCREEN_HEIGHT), mode)
            
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if not connected_to_server: continue
                
                insta_win_rect = pygame.Rect(sw - 160, 10, 150, 40)
                if insta_win_rect.collidepoint(mouse_pos):
                    send_message("insta_win", {})
                    continue

                ready_rect = pygame.Rect(sw // 2 - 100, sh - 150, 200, 60)
                play_again_rect = pygame.Rect(sw/2 - 125, sh - 100, 250, 60)
                
                if round_status == "waiting_for_players" and ready_rect.collidepoint(mouse_pos):
                    send_message("ready", {})
                    round_status = "waiting_for_opponent"
                    game_message = "Ready! Waiting for opponent..."
                elif game_over and play_again_rect.collidepoint(mouse_pos):
                    pass # Button is gone, so this won't trigger
                elif round_status == "waiting_for_choices":
                    for card_data in player_hand:
                        if "rect" in card_data and card_data["rect"] and card_data["rect"].collidepoint(mouse_pos):
                            player_choice = card_data
                            send_message("choice", {"choice": card_data})
                            round_status = "choice_made"
                            game_message = "Choice locked in! Waiting..."
                            break

        # --- Drawing ---
        draw_game_screen(sw, sh)
        pygame.display.flip()
        
        clock.tick(60)

    if connected_to_server:
        client_socket.close()
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    game_loop()
